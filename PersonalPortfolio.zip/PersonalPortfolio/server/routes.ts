import type { Express } from "express";
import { createServer, type Server } from "http";
import { sendEmail, isEmailConfigured } from "./emailService";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact form endpoint
  app.post("/api/contact", async (req, res) => {
    try {
      const { name, email, subject, message } = req.body;
      
      // Basic validation
      if (!name || !email || !message) {
        return res.status(400).json({ 
          message: "Name, email, and message are required" 
        });
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ 
          message: "Please provide a valid email address" 
        });
      }

      // Log the contact form submission
      console.log("Contact form submission:", {
        name,
        email,
        subject: subject || "Portfolio Contact",
        message,
        timestamp: new Date().toISOString()
      });

      // Send email notification to Lucky
      const emailSent = await sendEmail({
        to: "luckymishra310118@gmail.com", // Lucky's email
        from: "noreply@portfolio.com", // This needs to be a verified sender in SendGrid
        subject: `Portfolio Contact: ${subject || "New Message"}`,
        text: `
New contact form submission:

Name: ${name}
Email: ${email}
Subject: ${subject || "N/A"}

Message:
${message}

Timestamp: ${new Date().toISOString()}
        `,
        html: `
<h2>New Portfolio Contact Form Submission</h2>
<p><strong>Name:</strong> ${name}</p>
<p><strong>Email:</strong> ${email}</p>
<p><strong>Subject:</strong> ${subject || "N/A"}</p>
<p><strong>Message:</strong></p>
<p>${message.replace(/\n/g, '<br>')}</p>
<p><strong>Timestamp:</strong> ${new Date().toISOString()}</p>
        `
      });

      if (emailSent) {
        res.json({ 
          message: "Message sent successfully! I will get back to you soon.",
          success: true 
        });
      } else {
        // Even if email fails, still show success to user but log the issue
        console.error("Failed to send email notification");
        res.json({ 
          message: "Message received! I will get back to you soon.",
          success: true 
        });
      }
    } catch (error) {
      console.error("Contact form error:", error);
      res.status(500).json({ 
        message: "Failed to send message. Please try again later." 
      });
    }
  });

  // Resume download endpoint
  app.get("/api/resume/download", (req, res) => {
    try {
      const path = require('path');
      const fs = require('fs');
      
      const resumePath = path.join(process.cwd(), 'public', 'resume', 'lucky_mishra_resume.pdf');
      
      if (fs.existsSync(resumePath)) {
        res.download(resumePath, 'Lucky_Mishra_Data_Engineer_Resume.pdf');
      } else {
        res.status(404).json({ 
          message: "Resume file not found" 
        });
      }
    } catch (error) {
      console.error("Resume download error:", error);
      res.status(500).json({ 
        message: "Failed to download resume. Please try again later." 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
