import { CheckCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function AboutSection() {
  const keyStrengths = [
    "ETL Pipeline Architecture",
    "Big Data Processing with PySpark",
    "Cloud Platform Optimization", 
    "Performance Tuning & Cost Management"
  ];

  return (
    <section id="about" className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">About Me</h2>
          <p className="text-lg text-slate-600 max-w-3xl mx-auto">
            Passionate about transforming raw data into actionable insights through robust, scalable data engineering solutions.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Data pipeline visualization" 
              className="rounded-xl shadow-lg w-full h-auto"
            />
          </div>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold text-slate-900 mb-3">Data Engineering Expertise</h3>
              <p className="text-slate-600 leading-relaxed">
                Specialized in designing and implementing end-to-end data solutions across cloud platforms. 
                My expertise spans from data ingestion and transformation to creating robust analytical frameworks 
                that support data-driven decision making at scale.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold text-slate-900 mb-3">Cloud-Native Solutions</h3>
              <p className="text-slate-600 leading-relaxed">
                Experienced in building cloud-agnostic data architectures with a focus on performance optimization, 
                cost efficiency, and reliability. Successfully processed over 10TB of data daily while achieving 
                significant performance improvements and cost reductions.
              </p>
            </div>
            
            <Card className="bg-slate-50 border-slate-200">
              <CardContent className="p-6">
                <h4 className="font-semibold text-slate-900 mb-3">Key Strengths</h4>
                <ul className="space-y-2">
                  {keyStrengths.map((strength, index) => (
                    <li key={index} className="flex items-center text-slate-600">
                      <CheckCircle className="h-5 w-5 text-primary mr-3 flex-shrink-0" />
                      {strength}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
