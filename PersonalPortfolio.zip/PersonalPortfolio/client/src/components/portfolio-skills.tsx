import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Code,
  Database,
  Cloud,
  Server,
  Settings
} from "lucide-react";

export default function PortfolioSkills() {
  const skillCategories = [
    {
      title: "Programming Languages",
      skills: [
        { name: "Python", level: "Expert", icon: Code, color: "text-yellow-600" },
        { name: "SQL", level: "Advanced", icon: Database, color: "text-blue-600" },
        { name: "Java", level: "Intermediate", icon: Code, color: "text-red-600" },
        { name: "HiveQL", level: "Advanced", icon: Database, color: "text-orange-600" },
        { name: "Shell/Bash", level: "Intermediate", icon: Server, color: "text-slate-600" }
      ]
    },
    {
      title: "Big Data & Processing",
      skills: [
        { name: "Apache Spark", level: "Expert", icon: Server, color: "text-orange-600" },
        { name: "PySpark", level: "Expert", icon: Code, color: "text-blue-600" },
        { name: "Apache Kafka", level: "Intermediate", icon: Server, color: "text-slate-700" },
        { name: "Azure Data Factory", level: "Advanced", icon: Settings, color: "text-blue-500" },
        { name: "Azure Synapse", level: "Advanced", icon: Database, color: "text-blue-600" },
        { name: "Databricks", level: "Advanced", icon: Server, color: "text-orange-500" }
      ]
    },
    {
      title: "Cloud Platforms",
      skills: [
        { name: "Microsoft Azure", level: "Advanced", icon: Cloud, color: "text-blue-600" },
        { name: "Amazon AWS", level: "Intermediate", icon: Cloud, color: "text-orange-500" }
      ]
    },
    {
      title: "Databases & Storage",
      skills: [
        { name: "PostgreSQL", level: "Advanced", icon: Database, color: "text-blue-700" },
        { name: "MongoDB", level: "Intermediate", icon: Database, color: "text-green-600" },
        { name: "Data Lakes", level: "Advanced", icon: Database, color: "text-blue-600" },
        { name: "Data Warehousing", level: "Expert", icon: Database, color: "text-indigo-600" }
      ]
    }
  ];

  const getLevelColor = (level: string) => {
    switch (level) {
      case "Expert": return "bg-green-100 text-green-800";
      case "Advanced": return "bg-blue-100 text-blue-800";
      case "Intermediate": return "bg-yellow-100 text-yellow-800";
      default: return "bg-slate-100 text-slate-800";
    }
  };

  return (
    <section id="skills" className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Technical Skills</h2>
          <p className="text-lg text-slate-600">
            Comprehensive expertise across modern data engineering technologies and platforms
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {skillCategories.map((category, categoryIndex) => (
            <Card key={categoryIndex} className="border-slate-200 shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-slate-900 mb-4">{category.title}</h3>
                <div className="space-y-3">
                  {category.skills.map((skill, skillIndex) => {
                    const IconComponent = skill.icon;
                    return (
                      <div key={skillIndex} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {IconComponent && (
                            <IconComponent className={`h-5 w-5 ${skill.color}`} />
                          )}
                          <span className="text-slate-800 font-medium">{skill.name}</span>
                        </div>
                        <Badge 
                          variant="secondary" 
                          className={getLevelColor(skill.level)}
                        >
                          {skill.level}
                        </Badge>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Key Achievements Summary */}
        <div className="mt-12">
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-8">
              <h3 className="text-xl font-semibold text-slate-900 mb-4 text-center">
                Technical Achievements
              </h3>
              <div className="grid md:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-2xl font-bold text-blue-600 mb-2">10TB+</div>
                  <div className="text-sm text-slate-600">Daily Data Processing</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600 mb-2">67%</div>
                  <div className="text-sm text-slate-600">Performance Improvement</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-600 mb-2">7+</div>
                  <div className="text-sm text-slate-600">ETL Pipelines Built</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}