import { useState } from "react";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import { SiLinkedin, SiGithub, SiLeetcode, SiGeeksforgeeks } from "react-icons/si";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "", 
    subject: "",
    message: ""
  });

  const { toast } = useToast();

  const contactInfo = [
    {
      icon: Mail,
      title: "Email",
      value: "luckymishra310118@gmail.com",
      link: "mailto:luckymishra310118@gmail.com"
    },
    {
      icon: Phone,
      title: "Phone", 
      value: "+91-9319073062",
      link: "tel:+919319073062"
    },
    {
      icon: MapPin,
      title: "Location",
      value: "Delhi, India",
      link: null
    }
  ];

  const socialLinks = [
    {
      icon: SiLinkedin,
      href: "https://www.linkedin.com/in/lucky-mishra-539bb4251/",
      className: "bg-blue-600 text-white hover:bg-blue-700",
      label: "LinkedIn"
    },
    {
      icon: SiGithub,
      href: "https://github.com/Lucky-21052001", 
      className: "bg-slate-800 text-white hover:bg-slate-700",
      label: "GitHub"
    },
    {
      icon: SiLeetcode,
      href: "https://leetcode.com/u/luckymishra310118/",
      className: "bg-orange-500 text-white hover:bg-orange-600", 
      label: "LeetCode"
    },
    {
      icon: SiGeeksforgeeks,
      href: "https://www.geeksforgeeks.org/user/luckymish8pjg/",
      className: "bg-green-600 text-white hover:bg-green-700",
      label: "GeeksforGeeks"
    }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (response.ok) {
        toast({
          title: "Message Sent!",
          description: result.message || "Thank you for your message! I will get back to you soon."
        });

        // Reset form
        setFormData({
          name: "",
          email: "",
          subject: "",
          message: ""
        });
      } else {
        throw new Error(result.message || 'Failed to send message');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <section id="contact" className="py-16 bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Let's Connect</h2>
          <p className="text-lg text-slate-600">Open to exciting data engineering opportunities and collaborations</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div>
              <div className="space-y-6">
                {contactInfo.map((info, index) => {
                  const IconComponent = info.icon;
                  return (
                    <div key={index} className="flex items-center">
                      <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mr-4">
                        <IconComponent className="text-primary h-5 w-5" />
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900">{info.title}</div>
                        {info.link ? (
                          <a 
                            href={info.link} 
                            className="text-primary hover:text-primary/80 transition-colors"
                          >
                            {info.value}
                          </a>
                        ) : (
                          <span className="text-slate-600">{info.value}</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Social Links */}
              <div className="mt-8">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Professional Profiles</h3>
                <div className="flex space-x-4">
                  {socialLinks.map((social, index) => {
                    const IconComponent = social.icon;
                    return (
                      <Button
                        key={index}
                        size="sm"
                        className={`w-10 h-10 p-0 ${social.className}`}
                        asChild
                      >
                        <a 
                          href={social.href} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          aria-label={social.label}
                        >
                          <IconComponent className="h-4 w-4" />
                        </a>
                      </Button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <Card className="bg-white border-slate-200 shadow-lg">
              <CardContent className="p-8">
                <h3 className="text-xl font-bold text-slate-900 mb-6">Send a Message</h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="name" className="text-slate-700">Name *</Label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Your Name"
                      className="mt-2 border-slate-300 focus:border-primary focus:ring-primary"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email" className="text-slate-700">Email *</Label>
                    <Input
                      id="email"
                      name="email" 
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="your.email@example.com"
                      className="mt-2 border-slate-300 focus:border-primary focus:ring-primary"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="subject" className="text-slate-700">Subject</Label>
                    <Input
                      id="subject"
                      name="subject"
                      type="text"
                      value={formData.subject}
                      onChange={handleInputChange}
                      placeholder="Subject"
                      className="mt-2 border-slate-300 focus:border-primary focus:ring-primary"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="message" className="text-slate-700">Message *</Label>
                    <Textarea
                      id="message"
                      name="message"
                      rows={4}
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Your message..."
                      className="mt-2 border-slate-300 focus:border-primary focus:ring-primary resize-none"
                      required
                    />
                  </div>
                  
                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                    <Send className="mr-2 h-4 w-4" />
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
