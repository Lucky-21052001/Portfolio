import { useState } from "react";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { 
  SiLinkedin, 
  SiGithub, 
  SiLeetcode, 
  SiGeeksforgeeks 
} from "react-icons/si";

export default function PortfolioContact() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "", 
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const contactInfo = [
    {
      icon: Mail,
      title: "Email",
      value: "luckymishra310118@gmail.com",
      href: "mailto:luckymishra310118@gmail.com"
    },
    {
      icon: Phone,
      title: "Phone",
      value: "+91 9319073062",
      href: "tel:+919319073062"
    },
    {
      icon: MapPin,
      title: "Location",
      value: "Gurugram, India",
      href: "#"
    }
  ];

  const socialLinks = [
    {
      icon: SiLinkedin,
      href: "https://www.linkedin.com/in/lucky-mishra-539bb4251/",
      className: "bg-blue-600 text-white hover:bg-blue-700",
      label: "LinkedIn"
    },
    {
      icon: SiGithub,
      href: "https://github.com/Lucky-21052001", 
      className: "bg-slate-800 text-white hover:bg-slate-700",
      label: "GitHub"
    },
    {
      icon: SiLeetcode,
      href: "https://leetcode.com/u/luckymishra310118/",
      className: "bg-orange-500 text-white hover:bg-orange-600", 
      label: "LeetCode"
    },
    {
      icon: SiGeeksforgeeks,
      href: "https://www.geeksforgeeks.org/user/luckymish8pjg/",
      className: "bg-green-600 text-white hover:bg-green-700",
      label: "GeeksforGeeks"
    }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (response.ok) {
        toast({
          title: "Message Sent!",
          description: result.message || "Thank you for your message! I will get back to you soon."
        });

        setFormData({
          name: "",
          email: "",
          subject: "",
          message: ""
        });
      } else {
        throw new Error(result.message || 'Failed to send message');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-16 bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Let's Connect</h2>
          <p className="text-lg text-slate-600">Open to exciting data engineering opportunities and collaborations</p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold text-slate-900 mb-6">Get In Touch</h3>
                <div className="space-y-4">
                  {contactInfo.map((info, index) => {
                    const IconComponent = info.icon;
                    return (
                      <a
                        key={index}
                        href={info.href}
                        className="flex items-center p-4 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
                      >
                        <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mr-4">
                          <IconComponent className="text-blue-600 h-5 w-5" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-slate-900">{info.title}</div>
                          <div className="text-slate-600">{info.value}</div>
                        </div>
                      </a>
                    );
                  })}
                </div>
              </div>

              {/* Professional Profiles */}
              <div>
                <h3 className="text-xl font-semibold text-slate-900 mb-6">Professional Profiles</h3>
                <div className="grid grid-cols-2 gap-4">
                  {socialLinks.map((link, index) => {
                    const IconComponent = link.icon;
                    return (
                      <a
                        key={index}
                        href={link.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`${link.className} p-4 rounded-lg flex items-center justify-center space-x-2 transition-colors font-medium`}
                      >
                        <IconComponent className="h-5 w-5" />
                        <span className="text-sm">{link.label}</span>
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <Card className="border-slate-200 shadow-sm">
              <CardContent className="p-8">
                <h3 className="text-xl font-semibold text-slate-900 mb-6">Send Message</h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Input
                        type="text"
                        name="name"
                        placeholder="Your Name *"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        className="border-slate-300"
                      />
                    </div>
                    <div>
                      <Input
                        type="email"
                        name="email"
                        placeholder="Your Email *"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="border-slate-300"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Input
                      type="text"
                      name="subject"
                      placeholder="Subject"
                      value={formData.subject}
                      onChange={handleInputChange}
                      className="border-slate-300"
                    />
                  </div>
                  
                  <div>
                    <Textarea
                      name="message"
                      placeholder="Your Message *"
                      value={formData.message}
                      onChange={handleInputChange}
                      required
                      rows={5}
                      className="border-slate-300"
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      "Sending..."
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Send Message
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}