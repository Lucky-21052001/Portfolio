import { Trophy, Award, GraduationCap } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function AchievementsSection() {
  const achievements = [
    {
      icon: Trophy,
      iconColor: "text-primary",
      bgColor: "bg-gradient-to-br from-primary/5 to-primary/10",
      borderColor: "border-primary/20",
      title: "AIR 5 in IGDTUW-CET",
      description: "Top academic performance in competitive entrance examination"
    },
    {
      icon: Award,
      iconColor: "text-accent", 
      bgColor: "bg-gradient-to-br from-accent/5 to-accent/10",
      borderColor: "border-accent/20",
      title: "Azure Data Fundamentals",
      description: "Microsoft Certified: DP-900 - Cloud data fundamentals"
    },
    {
      icon: GraduationCap,
      iconColor: "text-secondary",
      bgColor: "bg-gradient-to-br from-secondary/5 to-secondary/10", 
      borderColor: "border-secondary/20",
      title: "CGPA: 8.4",
      description: "Master's in Computer Applications - IGDTUW, Delhi"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Achievements & Certifications</h2>
          <p className="text-lg text-slate-600">Recognition of excellence in academics and professional development</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {achievements.map((achievement, index) => {
            const IconComponent = achievement.icon;
            return (
              <Card 
                key={index} 
                className={`${achievement.bgColor} border ${achievement.borderColor} card-hover`}
              >
                <CardContent className="p-6 text-center">
                  <div className={`bg-${achievement.iconColor.split('-')[1]}/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <IconComponent className={`${achievement.iconColor} h-8 w-8`} />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2">{achievement.title}</h3>
                  <p className="text-slate-600 text-sm">{achievement.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
