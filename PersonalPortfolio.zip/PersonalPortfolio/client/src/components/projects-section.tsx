import { ExternalLink, CheckCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function ProjectsSection() {
  const projects = [
    {
      title: "Flight Analytics Pipeline with Delta Live Tables",
      description: "Implemented a comprehensive data pipeline using Delta Live Tables for streamlined data ingestion with automated quality checks and parameterized PySpark functions for enhanced reusability.",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
      features: [
        "Auto Loader with Delta Live Tables for streamlined data ingestion",
        "Lakehouse architecture using medallion model and Unity Catalog", 
        "dbt analytical models with materialized views for insights"
      ],
      technologies: ["PySpark", "Databricks", "Delta Live Tables", "dbt", "Auto Loader"],
      color: "primary"
    },
    {
      title: "End-to-End Data Lakehouse Pipeline", 
      description: "Developed a complete ETL pipeline using Azure Data Factory with incremental data loading, transforming bronze layer data to silver and gold layers for efficient analytics and reporting.",
      image: "https://images.unsplash.com/photo-1639322537228-f710d846310a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
      features: [
        "Complete ETL pipeline with ADF from SQL database to ADLS",
        "Incremental data loading with optimized pipeline efficiency",
        "Dimensional and fact tables in Delta format for analytics"
      ],
      technologies: ["Azure Data Factory", "Azure Databricks", "ADLS Gen2", "Azure Synapse", "Delta Format"],
      color: "accent"
    }
  ];

  return (
    <section id="projects" className="py-16 bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Featured Projects</h2>
          <p className="text-lg text-slate-600">Showcasing end-to-end data engineering solutions and innovations</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <Card key={index} className="bg-white border-slate-200 shadow-lg overflow-hidden card-hover">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-slate-900">{project.title}</h3>
                  <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
                
                <img 
                  src={project.image} 
                  alt={`${project.title} visualization`}
                  className="rounded-lg mb-6 w-full h-48 object-cover"
                />

                <p className="text-slate-600 mb-6">
                  {project.description}
                </p>

                <div className="space-y-4 mb-6">
                  {project.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start">
                      <CheckCircle className={`h-5 w-5 ${project.color === 'primary' ? 'text-primary' : 'text-accent'} mr-3 mt-0.5 flex-shrink-0`} />
                      <span className="text-slate-600 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech, techIndex) => (
                    <Badge 
                      key={techIndex}
                      className={project.color === 'primary' 
                        ? "bg-primary/10 text-primary hover:bg-primary/20" 
                        : "bg-accent/10 text-accent hover:bg-accent/20"
                      }
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
