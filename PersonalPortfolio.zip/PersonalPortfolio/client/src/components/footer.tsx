export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-slate-900 text-slate-300 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="text-2xl font-bold text-white mb-2">Lucky</div>
          <p className="text-slate-400 mb-4">Data Engineer | Building scalable data solutions</p>
          <p className="text-sm text-slate-500">© {currentYear} Lucky. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
