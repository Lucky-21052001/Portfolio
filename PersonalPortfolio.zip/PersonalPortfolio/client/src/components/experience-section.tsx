import { Database, Bot, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SiAccenture } from "react-icons/si";

export default function ExperienceSection() {
  const achievements = [
    {
      icon: Database,
      iconColor: "text-primary",
      bgColor: "bg-primary/10",
      title: "ETL Pipeline Development:",
      description: "Developed and maintained 7+ ETL pipelines using PySpark in Azure Databricks, processing over 10 TB of data daily"
    },
    {
      icon: Bot,
      iconColor: "text-accent", 
      bgColor: "bg-accent/10",
      title: "Workflow Automation:",
      description: "Automated 10+ data workflows in Azure Data Factory, reducing manual intervention by 80%"
    },
    {
      icon: TrendingUp,
      iconColor: "text-secondary",
      bgColor: "bg-secondary/10", 
      title: "Performance Optimization:",
      description: "Reduced runtime from 18 to 6 hours and cut resource usage by 40%, resulting in 10% lower storage costs"
    }
  ];

  const technologies = [
    "Azure Databricks",
    "PySpark", 
    "Azure Data Factory",
    "Azure Synapse"
  ];

  return (
    <section id="experience" className="py-16 bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Professional Experience</h2>
          <p className="text-lg text-slate-600">Building enterprise-scale data solutions at industry leaders</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="border-slate-200 shadow-lg">
            <CardContent className="p-8">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between mb-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 rounded-lg p-3 flex-shrink-0">
                    <SiAccenture className="h-8 w-8 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">Associate Software Engineer</h3>
                    <div className="text-lg text-primary font-semibold">Accenture Solutions Pvt. Ltd.</div>
                    <div className="text-slate-600">Gurugram, India</div>
                  </div>
                </div>
                <div className="mt-2 lg:mt-0">
                  <Badge className="bg-primary/10 text-primary hover:bg-primary/20">
                    08/2024 – Present
                  </Badge>
                </div>
              </div>

              <div className="grid lg:grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold text-slate-900 mb-4">Key Achievements</h4>
                  <ul className="space-y-4">
                    {achievements.map((achievement, index) => {
                      const IconComponent = achievement.icon;
                      return (
                        <li key={index} className="flex items-start">
                          <div className={`${achievement.bgColor} rounded-full p-1 mr-3 mt-1`}>
                            <IconComponent className={`${achievement.iconColor} h-4 w-4`} />
                          </div>
                          <div>
                            <strong className="text-slate-900">{achievement.title}</strong>
                            <span className="text-slate-600"> {achievement.description}</span>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </div>

                <div>
                  <img 
                    src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                    alt="Cloud data architecture visualization" 
                    className="rounded-lg shadow-md w-full h-auto"
                  />
                  
                  <Card className="mt-6 bg-slate-50 border-slate-200">
                    <CardContent className="p-4">
                      <h5 className="font-semibold text-slate-900 mb-3">Technologies Used</h5>
                      <div className="flex flex-wrap gap-2">
                        {technologies.map((tech, index) => (
                          <Badge 
                            key={index}
                            variant="secondary"
                            className="bg-primary/10 text-primary hover:bg-primary/20"
                          >
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
