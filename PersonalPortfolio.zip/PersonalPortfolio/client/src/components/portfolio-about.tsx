import { CheckCircle, Code, Cloud, Database } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function PortfolioAbout() {
  const keyStrengths = [
    "ETL Pipeline Architecture & Design",
    "Big Data Processing with PySpark", 
    "Cloud Platform Optimization",
    "Performance Tuning & Cost Management",
    "Data Warehouse & Analytics Solutions",
    "Workflow Automation & Orchestration"
  ];

  const expertise = [
    {
      icon: Database,
      title: "Data Engineering",
      description: "Specialized in designing end-to-end data solutions, from ingestion to transformation, supporting data-driven decision making at scale."
    },
    {
      icon: Cloud,
      title: "Cloud Solutions",
      description: "Expert in building cloud-agnostic data architectures with focus on performance, cost efficiency, and reliability across platforms."
    },
    {
      icon: Code,
      title: "Big Data Processing",
      description: "Experienced in processing over 10TB of data daily using PySpark, achieving significant performance improvements and cost reductions."
    }
  ];

  return (
    <section id="about" className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">About Me</h2>
          <p className="text-lg text-slate-600 max-w-3xl mx-auto">
            Passionate about transforming raw data into actionable insights through robust, scalable data engineering solutions.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {expertise.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <Card key={index} className="border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">{item.title}</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">{item.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Card className="bg-slate-50 border-slate-200">
          <CardContent className="p-8">
            <h3 className="text-xl font-semibold text-slate-900 mb-6 text-center">Core Competencies</h3>
            <div className="grid md:grid-cols-2 gap-4">
              {keyStrengths.map((strength, index) => (
                <div key={index} className="flex items-center text-slate-700">
                  <CheckCircle className="h-5 w-5 text-blue-600 mr-3 flex-shrink-0" />
                  {strength}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}