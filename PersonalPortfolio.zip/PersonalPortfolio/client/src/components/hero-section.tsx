import { Download, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function HeroSection() {
  const handleDownloadResume = () => {
    // Create a temporary link element to trigger download
    const link = document.createElement('a');
    link.href = '/resume/lucky_mishra_resume.pdf';
    link.download = 'Lucky_Mishra_Data_Engineer_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section className="pt-24 pb-16 gradient-bg">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="mb-4">
              <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                Data Engineer
              </Badge>
            </div>
            
            <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
              Building Scalable Data Solutions in the Cloud
            </h1>
            
            <p className="text-xl text-slate-600 mb-8 leading-relaxed">
              Results-driven Data Engineer with 1+ year of experience architecting scalable ETL pipelines in cloud ecosystems. Specialized in big data processing using PySpark and Databricks, with expertise across multiple cloud platforms.
            </p>
            
            {/* Key Metrics */}
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              <Card className="border-slate-200 shadow-sm card-hover">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-primary mb-1">10TB</div>
                  <div className="text-sm text-slate-600">Daily Data Processing</div>
                </CardContent>
              </Card>
              
              <Card className="border-slate-200 shadow-sm card-hover">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-accent mb-1">67%</div>
                  <div className="text-sm text-slate-600">Performance Improvement</div>
                </CardContent>
              </Card>
              
              <Card className="border-slate-200 shadow-sm card-hover lg:col-span-1 col-span-2">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-secondary mb-1">80%</div>
                  <div className="text-sm text-slate-600">Manual Work Reduction</div>
                </CardContent>
              </Card>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button onClick={scrollToContact} size="lg" className="bg-primary hover:bg-primary/90">
                <Mail className="mr-2 h-4 w-4" />
                Get In Touch
              </Button>
              <Button 
                onClick={handleDownloadResume} 
                variant="outline" 
                size="lg"
                className="border-slate-300 text-slate-700 hover:bg-slate-50"
              >
                <Download className="mr-2 h-4 w-4" />
                Download Resume
              </Button>
            </div>
          </div>
          
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              <img 
                src="/lucky-profile.jpg" 
                alt="Lucky Mishra - Data Engineer"
                className="rounded-2xl shadow-2xl w-80 h-80 lg:w-96 lg:h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/10 to-transparent rounded-2xl"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
