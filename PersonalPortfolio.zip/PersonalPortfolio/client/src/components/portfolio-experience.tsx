import { Database, Bot, TrendingUp, Calendar } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SiAccenture } from "react-icons/si";

export default function PortfolioExperience() {
  const achievements = [
    {
      icon: Database,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-100",
      title: "ETL Pipeline Development",
      description: "Developed and maintained 7+ ETL pipelines using PySpark in cloud environments, processing over 10 TB of data daily"
    },
    {
      icon: Bot,
      iconColor: "text-green-600", 
      bgColor: "bg-green-100",
      title: "Workflow Automation",
      description: "Automated 10+ data workflows using cloud orchestration tools, reducing manual intervention by 80%"
    },
    {
      icon: TrendingUp,
      iconColor: "text-purple-600",
      bgColor: "bg-purple-100", 
      title: "Performance Optimization",
      description: "Reduced runtime from 18 to 6 hours and cut resource usage by 40%, resulting in 10% lower storage costs"
    }
  ];

  const technologies = [
    "PySpark",
    "Python", 
    "SQL",
    "Apache Spark",
    "Data Factory",
    "Cloud Platforms",
    "ETL/ELT",
    "Data Warehousing"
  ];

  return (
    <section id="experience" className="py-16 bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Professional Experience</h2>
          <p className="text-lg text-slate-600">Building enterprise-scale data solutions at industry leaders</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="border-slate-200 shadow-lg">
            <CardContent className="p-8">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between mb-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 rounded-lg p-3 flex-shrink-0">
                    <SiAccenture className="h-8 w-8 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">Associate Software Engineer</h3>
                    <div className="text-lg text-blue-600 font-semibold">Accenture Solutions Pvt. Ltd.</div>
                    <div className="text-slate-600 flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      Gurugram, India
                    </div>
                  </div>
                </div>
                <div className="mt-2 lg:mt-0">
                  <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                    08/2024 – Present
                  </Badge>
                </div>
              </div>

              <div className="grid lg:grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold text-slate-900 mb-4">Key Achievements</h4>
                  <ul className="space-y-4">
                    {achievements.map((achievement, index) => {
                      const IconComponent = achievement.icon;
                      return (
                        <li key={index} className="flex items-start">
                          <div className={`${achievement.bgColor} rounded-full p-2 mr-3 mt-1`}>
                            <IconComponent className={`${achievement.iconColor} h-4 w-4`} />
                          </div>
                          <div>
                            <strong className="text-slate-900">{achievement.title}:</strong>
                            <p className="text-slate-600 text-sm mt-1">{achievement.description}</p>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold text-slate-900 mb-4">Technologies & Tools</h4>
                  <div className="flex flex-wrap gap-2">
                    {technologies.map((tech, index) => (
                      <Badge 
                        key={index} 
                        variant="secondary" 
                        className="bg-slate-100 text-slate-700 hover:bg-slate-200"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}