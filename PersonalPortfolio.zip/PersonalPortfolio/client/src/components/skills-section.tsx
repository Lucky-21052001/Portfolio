import { Cloud, Code, Wrench } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function SkillsSection() {
  const skillCategories = [
    {
      icon: Cloud,
      iconColor: "text-primary",
      bgColor: "bg-primary/10",
      title: "Cloud & Big Data",
      skills: [
        "Azure Data Factory",
        "Databricks", 
        "Azure Synapse",
        "Data Lake Gen2",
        "Delta Lake",
        "Hadoop",
        "Apache Spark",
        "Hive"
      ]
    },
    {
      icon: Code,
      iconColor: "text-accent",
      bgColor: "bg-accent/10", 
      title: "Programming & Libraries",
      skills: [
        "Python",
        "Java",
        "SQL", 
        "PySpark",
        "Pandas",
        "NumPy",
        "Scikit-learn",
        "dbt"
      ]
    },
    {
      icon: Wrench,
      iconColor: "text-secondary",
      bgColor: "bg-secondary/10",
      title: "Developer Tools", 
      skills: [
        "Git",
        "Visual Studio",
        "Jupyter",
        "Oracle SQL Developer",
        "ETL Tools",
        "Unity Catalog"
      ]
    }
  ];

  return (
    <section id="skills" className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Technical Skills</h2>
          <p className="text-lg text-slate-600">Comprehensive expertise across modern data engineering technologies</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => {
            const IconComponent = category.icon;
            return (
              <Card key={index} className="bg-slate-50 border-slate-200 card-hover">
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    <div className={`${category.bgColor} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4`}>
                      <IconComponent className={`${category.iconColor} h-8 w-8`} />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900">{category.title}</h3>
                  </div>
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-2">
                      {category.skills.map((skill, skillIndex) => (
                        <Badge 
                          key={skillIndex}
                          variant="outline"
                          className="bg-white border-slate-200 text-slate-700 hover:bg-slate-100"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
