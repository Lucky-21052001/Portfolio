import { Download, Mail, MapPin, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function PortfolioHero() {
  const handleDownloadResume = () => {
    const link = document.createElement('a');
    link.href = '/lucky_resume.pdf';
    link.download = 'Lucky_Mishra_Data_Engineer_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section className="pt-24 pb-16 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left side - Content */}
          <div className="space-y-8">
            <div>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800 mb-4">
                Data Engineer
              </Badge>
              <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6 leading-tight">
                Hi, I'm <span className="text-blue-600">Lucky Mishra</span>
              </h1>
              <p className="text-xl text-slate-600 mb-6 leading-relaxed">
                Building Scalable Data Solutions in the Cloud
              </p>
              <p className="text-lg text-slate-600 leading-relaxed">
                Results-driven Data Engineer with 1+ year of experience architecting scalable ETL pipelines. 
                Specialized in big data processing using PySpark and cloud platforms, with expertise in 
                optimizing performance and reducing costs.
              </p>
            </div>

            {/* Contact Info */}
            <div className="flex flex-wrap gap-4 text-sm text-slate-600">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                <span>Gurugram, India</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>+91 9319073062</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>luckymishra310118@gmail.com</span>
              </div>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-3 gap-4">
              <Card className="border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-600 mb-1">10TB</div>
                  <div className="text-sm text-slate-600">Daily Data Processing</div>
                </CardContent>
              </Card>
              <Card className="border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-600 mb-1">67%</div>
                  <div className="text-sm text-slate-600">Performance Improvement</div>
                </CardContent>
              </Card>
              <Card className="border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-purple-600 mb-1">80%</div>
                  <div className="text-sm text-slate-600">Manual Work Reduction</div>
                </CardContent>
              </Card>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button onClick={scrollToContact} size="lg" className="bg-blue-600 hover:bg-blue-700">
                <Mail className="mr-2 h-4 w-4" />
                Get In Touch
              </Button>
              <Button 
                onClick={handleDownloadResume} 
                variant="outline" 
                size="lg"
                className="border-slate-300 text-slate-700 hover:bg-slate-50"
              >
                <Download className="mr-2 h-4 w-4" />
                Download Resume
              </Button>
            </div>
          </div>

          {/* Right side - Profile Photo */}
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl blur opacity-20"></div>
              <img 
                src="/lucky-profile.jpg" 
                alt="Lucky Mishra - Data Engineer"
                className="relative rounded-2xl shadow-2xl w-80 h-80 lg:w-96 lg:h-96 object-cover border-4 border-white"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}