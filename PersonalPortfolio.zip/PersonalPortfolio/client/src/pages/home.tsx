import PortfolioNavbar from "@/components/portfolio-navbar";
import PortfolioHero from "@/components/portfolio-hero";
import PortfolioAbout from "@/components/portfolio-about";
import PortfolioExperience from "@/components/portfolio-experience";
import PortfolioSkills from "@/components/portfolio-skills";
import PortfolioContact from "@/components/portfolio-contact";

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <PortfolioNavbar />
      <PortfolioHero />
      <PortfolioAbout />
      <PortfolioExperience />
      <PortfolioSkills />
      <PortfolioContact />
      
      {/* Footer */}
      <footer className="bg-slate-900 text-white py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-slate-300">
            © 2025 Lucky Mishra. All rights reserved. Built with React & TypeScript.
          </p>
        </div>
      </footer>
    </div>
  );
}
