# Portfolio Website - Data Engineer

## Overview

This is a modern, responsive portfolio website for Lucky, a Data Engineer with expertise in Azure cloud ecosystem and big data processing. The application is built as a full-stack web application using React frontend with Express.js backend, featuring a clean, professional design showcasing technical skills, experience, and projects.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with clear separation between frontend and backend components:

- **Frontend**: React-based single page application (SPA) with TypeScript
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (configured but minimal usage)
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Build System**: Vite for frontend bundling and development
- **Deployment**: Node.js production server

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: React Query (@tanstack/react-query) for server state
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Server**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Session Management**: Basic in-memory storage (expandable to database)
- **API Design**: RESTful endpoints with JSON responses
- **Error Handling**: Centralized error middleware

### Component Structure
The frontend is organized into modular components:
- **Layout Components**: Navbar, Footer, Hero Section
- **Content Sections**: About, Experience, Skills, Projects, Achievements, Contact
- **UI Components**: Complete shadcn/ui component library
- **Pages**: Home page and 404 Not Found page

### Database Schema
Minimal schema with user authentication structure:
- **Users table**: Basic user management with username/password
- Configured for PostgreSQL via Neon Database serverless

## Data Flow

1. **Client Requests**: React frontend makes API calls using React Query
2. **Server Processing**: Express.js handles routing and business logic
3. **Database Operations**: Drizzle ORM manages database interactions
4. **Response Handling**: JSON responses with proper error handling
5. **UI Updates**: React Query manages cache and UI state updates

### Contact Form Flow
- Form validation using React Hook Form + Zod
- POST request to `/api/contact` endpoint
- Server-side validation and logging
- Success/error feedback via toast notifications

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React, React DOM
- **Routing**: wouter
- **State Management**: @tanstack/react-query
- **UI Components**: @radix-ui/* components, shadcn/ui
- **Forms**: react-hook-form, @hookform/resolvers
- **Styling**: tailwindcss, class-variance-authority, clsx
- **Icons**: lucide-react, react-icons
- **Utilities**: date-fns, embla-carousel-react

### Backend Dependencies
- **Server**: express
- **Database**: drizzle-orm, @neondatabase/serverless
- **Session**: connect-pg-simple
- **Validation**: drizzle-zod, zod
- **Build Tools**: tsx, esbuild

### Development Dependencies
- **Build System**: vite, @vitejs/plugin-react
- **TypeScript**: Full TypeScript support across frontend and backend
- **Development Tools**: @replit/vite-plugin-runtime-error-modal

## Deployment Strategy

### Development Environment
- **Frontend**: Vite dev server with hot module replacement
- **Backend**: tsx for TypeScript execution with auto-reload
- **Database**: Neon Database serverless PostgreSQL
- **Environment**: Environment variables for database connection

### Production Build
1. **Frontend Build**: Vite builds optimized React application
2. **Backend Build**: esbuild bundles server code for Node.js
3. **Static Assets**: Frontend assets served from Express server
4. **Database Migrations**: Drizzle Kit for schema management

### Build Commands
- `npm run dev`: Development mode with concurrent frontend/backend
- `npm run build`: Production build (frontend + backend)
- `npm run start`: Production server
- `npm run db:push`: Database schema deployment

### Architecture Decisions

**Problem**: Need for a professional portfolio website showcasing technical expertise
**Solution**: Full-stack web application with modern React frontend and Express backend
**Rationale**: Demonstrates technical skills while providing a platform for professional presentation

**Problem**: UI consistency and development speed
**Solution**: shadcn/ui component library with Tailwind CSS
**Rationale**: Pre-built, accessible components with consistent design system and fast development

**Problem**: Type safety across frontend and backend
**Solution**: Full TypeScript implementation with shared schema types
**Rationale**: Reduces runtime errors and improves developer experience

**Problem**: Database flexibility and type safety
**Solution**: Drizzle ORM with PostgreSQL
**Rationale**: Type-safe database operations with modern developer experience, though minimally used in current implementation

The application is designed to be easily extensible for additional features like blog posts, project galleries, or enhanced contact management while maintaining clean architecture and performance.